# Configuração do chat

A Happy Nation IA usa o gateway LLM integrado ao backend. A chamada é feita exclusivamente em `server/routers.ts` por `invokeLLM`, portanto nenhuma chave ou credencial chega ao navegador. O provedor e a autenticação ficam sob a configuração segura do ambiente gerenciado; a interface pública não expõe seletor de modelo nem parâmetros sensíveis.

A experiência visual apresenta a resposta progressivamente e mantém estados de carregamento, erro, vazio, nova conversa e interrupção da exibição. Como o helper padrão atual retorna a conclusão completa antes de entregá-la ao procedimento tRPC, o botão de parar interrompe a revelação local e ignora o resultado restante, mas não cancela o processamento já iniciado no gateway. Essa decisão evita criar uma rota SSE paralela fora do contrato tRPC do template.

Para um futuro modo de streaming de transporte, a evolução recomendada é adicionar um endpoint SSE ao servidor e um helper de LLM que aceite `AbortSignal`, preservando a mesma política de sistema, autenticação e armazenamento de segredos.
