# Configuração da IA

A Happy Nation IA chama o provedor de modelos exclusivamente no backend. Em produção externa, o adaptador aceita `GEMINI_API_KEY` e usa o modelo `gemini-2.0-flash` por padrão; essa chave deve ser cadastrada como segredo no Render e nunca entrar no frontend, no GitHub ou em logs.

O chat mantém o histórico persistente apenas para usuários autenticados. A interface apresenta respostas progressivamente e permite cancelar a exibição local; o cancelamento de transporte da requisição é uma evolução futura. O Markdown é renderizado no cliente, com cópia do texto completo e cópia específica de blocos de código.

Para operar sem mensalidade, use o plano gratuito do Render e a cota gratuita disponível no provedor Gemini, respeitando os limites e os termos vigentes de cada serviço. Hospedagem gratuita não significa cota ilimitada de inferência: quando a cota do modelo for atingida, o chat deve informar a indisponibilidade sem expor a chave.

## Variáveis de produção

| Variável | Onde fica | Finalidade |
|---|---|---|
| `GEMINI_API_KEY` | Render → Environment | Autorizar chamadas ao Gemini; valor secreto |
| `DATABASE_URL` | Render → Environment | Conectar o banco MySQL/TiDB do histórico |
| `JWT_SECRET` | Render → Environment | Assinar sessões do aplicativo |
| `OAUTH_SERVER_URL` e variáveis OAuth | Render → Environment | Login seguro, quando o OAuth externo estiver configurado |

Nunca cole uma chave em mensagens, commits ou arquivos públicos. No plano gratuito, o serviço pode dormir após inatividade e retornar mais lentamente no primeiro acesso.
