# Publicação da Happy Nation IA

A Happy Nation IA está preparada para publicação na hospedagem gerenciada gratuita disponibilizada pelo ambiente do projeto. O modo gratuito é adequado para uma aplicação web pública com backend tRPC, banco de dados e autenticação. O projeto não depende de processo externo, Docker ou servidor mantido manualmente.

A publicação não é executada automaticamente. Para disponibilizar um link público, abra o checkpoint mais recente no painel de gerenciamento e selecione **Publish**. Depois da publicação, o endereço público poderá ser compartilhado e a aplicação continuará acessível conforme os limites da hospedagem gratuita.

O histórico persistente exige login. Visitantes sem sessão continuam usando o fallback local do navegador; usuários autenticados têm suas conversas e mensagens vinculadas à própria conta. As tabelas `conversations` e `conversationMessages` já foram criadas no banco, com ordenação explícita por `position`.
