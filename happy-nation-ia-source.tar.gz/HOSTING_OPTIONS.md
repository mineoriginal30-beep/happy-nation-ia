# Opções de hospedagem externa gratuita

## Avaliação em 22/08/2026

| Opção | Compatibilidade | Custo | Limitações principais |
| --- | --- | --- | --- |
| Render Web Service Free + TiDB Cloud Starter | Boa para Node/Express e MySQL compatível | Gratuita dentro das cotas | O serviço gratuito do Render pode dormir após 15 minutos sem tráfego; o banco e as cotas dos provedores devem ser acompanhados. |
| Render Web Service Free + migração para Render Postgres | Possível, mas exige conversão de MySQL/Drizzle para PostgreSQL | Gratuita inicialmente | O Postgres gratuito do Render expira após 30 dias; exige migração de esquema e conexão. |

A documentação oficial do Render confirma que Web Services Node.js podem usar instância Free e receber URL `onrender.com`, mas informa suspensão por inatividade, sistema de arquivos efêmero e limites de uso. Para preservar o histórico, não se deve usar SQLite ou arquivos locais no serviço gratuito. Referência: https://render.com/docs/free.

A aplicação atual usa Drizzle com `mysql2`, portanto a primeira opção preserva melhor o código: hospedar o Node/Express no Render e conectar a um banco MySQL compatível externo, como TiDB Cloud Starter. A conta do provedor externo e a criação do banco precisam ser autorizadas pelo proprietário; segredos devem ser inseridos no painel do provedor, nunca no GitHub.

O deploy exige um repositório Git conectado, comando de build `pnpm build`, comando de inicialização `pnpm start`, variáveis de ambiente e a porta fornecida pelo ambiente. Referência do fluxo Node/Express: https://render.com/docs/deploy-node-express-app.
