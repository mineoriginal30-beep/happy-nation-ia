# QA — Happy Nation IA

## Verificações executadas em 22/08/2026

A interface pública foi revisada em viewport desktop de 1280×720, tablet de 768×1024 e celular de 390×844. O layout permanece legível, o menu móvel abre por botão com rótulo acessível, o chat mantém área de entrada utilizável e a navegação pública não apresenta a rota administrativa.

A checagem de teclado confirmou que links, botões, sugestões do chat, textarea, botão de envio, botão de limpeza, login, instalação e ação “Copiar código” são elementos nativos focáveis. Foi aplicado `:focus-visible` global com contorno verde de alto destaque, além de foco específico na ação de copiar e no menu móvel. O botão de limpeza recebeu `aria-label="Limpar conversa"`, e o botão de código recebe `aria-label="Copiar bloco de código"`.

A checagem de contraste foi feita por inspeção visual nas três viewports: texto principal branco sobre superfícies azul-marinho/preto, texto secundário em cinza claro e ações principais em verde-mint escuro. Estados de foco têm contorno verde-mint contrastante.

A cópia de fenced code foi validada por teste unitário em `server/ai.chat.test.ts`: a entrada `Veja: ```ts ... ``` Fim.` produz somente `{ language: "ts", code: "..." }`, enquanto a UI apresenta o botão “Copiar código” no bloco renderizado. A implementação usa `navigator.clipboard.writeText(code)` e não copia o texto complementar.

A autenticação administrativa foi validada com dois testes: uma sessão sem função administrativa recebe `FORBIDDEN`, enquanto uma sessão com `role: "admin"` recebe status autorizado. O build, a checagem TypeScript e os seis testes Vitest passam.

## Verificação UX — Markdown e cópia

A resposta da IA é renderizada pelo `Streamdown` dentro de um contêiner com `aria-live="polite"`. A revisão visual confirma hierarquia para títulos, parágrafos, listas ordenadas e não ordenadas, citações, links e código inline, com estilos próprios no tema escuro da Happy Nation IA. Blocos fenced são destacados em `CodeBlock`, exibem linguagem e possuem o botão “Copiar código”, que copia somente o conteúdo do bloco. O botão “Copiar” da resposta copia o texto completo e troca temporariamente para “Copiado”.

A compatibilidade com o histórico é garantida porque as mensagens persistidas mantêm o Markdown original no campo `content`; ao reabrir uma conversa, o conteúdo volta ao mesmo pipeline `MessageContent`/`Streamdown`, sem conversão para texto simples. A checagem automatizada correspondente está em `server/ai.chat.test.ts` para fenced code e em `server/history.test.ts` para criação, retomada e sincronização. A checagem visual da faixa “SEU HISTÓRICO” foi realizada em desktop autenticado após a integração do recurso.
