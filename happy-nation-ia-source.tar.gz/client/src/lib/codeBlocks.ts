export function extractCodeBlocks(content: string) {
  const blocks: Array<{ language: string; code: string }> = [];
  const fence = /```([\w+-]*)\n([\s\S]*?)```/g;
  let match: RegExpExecArray | null;
  while ((match = fence.exec(content))) {
    blocks.push({ language: match[1] || "", code: match[2].trimEnd() });
  }
  return blocks;
}
