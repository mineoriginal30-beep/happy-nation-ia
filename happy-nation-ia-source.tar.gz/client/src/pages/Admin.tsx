import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, LockKeyhole, ShieldCheck } from "lucide-react";
import { Link } from "wouter";

export default function Admin() {
  const status = trpc.admin.status.useQuery();

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#05070c] p-6 text-white md:p-10">
        <div className="mx-auto max-w-4xl">
          <Link href="/" className="mb-10 inline-flex items-center gap-2 text-sm text-slate-400 hover:text-[#76ffbb]"><ArrowLeft size={16} /> Voltar para a Happy Nation IA</Link>
          <div className="rounded-2xl border border-[#76ffbb]/20 bg-[#0b111a]/90 p-8 shadow-2xl">
            <div className="mb-8 flex items-center gap-4">
              <div className="grid size-12 place-items-center rounded-xl border border-[#76ffbb]/40 bg-[#76ffbb]/10 text-[#76ffbb]"><LockKeyhole size={21} /></div>
              <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#76ffbb]">private control</p><h1 className="text-3xl font-semibold tracking-tight">Painel administrativo</h1></div>
            </div>
            {status.isLoading && <p className="text-slate-400">Validando permissões...</p>}
            {status.error && <div className="rounded-xl border border-red-400/30 bg-red-400/10 p-4 text-red-200">Acesso negado. Esta área exige uma conta com função administrativa.</div>}
            {status.data && <div className="grid gap-4 md:grid-cols-3"><div className="rounded-xl border border-white/10 bg-white/[.03] p-5"><ShieldCheck className="mb-4 text-[#76ffbb]" size={20} /><p className="font-mono text-[10px] uppercase tracking-widest text-slate-500">Sessão</p><p className="mt-2 font-medium">Protegida</p></div><div className="rounded-xl border border-white/10 bg-white/[.03] p-5"><p className="font-mono text-[10px] uppercase tracking-widest text-slate-500">Função</p><p className="mt-2 font-medium">{status.data.role}</p></div><div className="rounded-xl border border-white/10 bg-white/[.03] p-5"><p className="font-mono text-[10px] uppercase tracking-widest text-slate-500">Administrador</p><p className="mt-2 font-medium">{status.data.name || "Conta autorizada"}</p></div></div>}
            <p className="mt-8 max-w-2xl text-sm leading-7 text-slate-400">As credenciais do provedor e as funções administrativas permanecem no servidor. A rota não aparece na navegação pública; o bloqueio de autorização é aplicado no backend.</p>
            <Button variant="outline" className="mt-6" onClick={() => window.location.href = "/"}>Ir para a interface pública</Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
