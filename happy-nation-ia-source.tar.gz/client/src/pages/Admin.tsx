import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Admin() {
  const { data: user, isLoading: authLoading } = trpc.auth.me.useQuery();
  const overview = trpc.admin.overview.useQuery(undefined, { enabled: user?.role === "admin" });
  if (authLoading) return <div className="min-h-screen grid place-items-center">Carregando...</div>;
  if (!user || user.role !== "admin") return <main className="min-h-screen grid place-items-center bg-slate-950 text-white p-6"><Card className="bg-slate-900 border-slate-800 text-white max-w-md"><CardHeader><CardTitle>Acesso restrito</CardTitle></CardHeader><CardContent className="space-y-4"><p>Esta área é exclusiva para administradores.</p><Link href="/"><Button>Voltar para a área do usuário</Button></Link></CardContent></Card></main>;
  const balance = overview.data?.data;
  return <main className="min-h-screen bg-slate-950 text-white p-6"><div className="max-w-6xl mx-auto space-y-6"><header className="flex items-center justify-between"><div><p className="text-amber-400 text-sm font-semibold">ADMINISTRAÇÃO</p><h1 className="text-3xl font-bold">Painel operacional</h1></div><Link href="/"><Button variant="outline">Área do usuário</Button></Link></header><section className="grid md:grid-cols-3 gap-4"><Card className="bg-slate-900 border-slate-800 text-white"><CardHeader><CardTitle>Saldo disponível</CardTitle></CardHeader><CardContent className="text-2xl font-bold">R$ {balance?.available?.value ?? "—"}</CardContent></Card><Card className="bg-slate-900 border-slate-800 text-white"><CardHeader><CardTitle>Total recebido</CardTitle></CardHeader><CardContent className="text-2xl font-bold">R$ {balance?.stats_30d?.total_in?.value ?? "—"}</CardContent></Card><Card className="bg-slate-900 border-slate-800 text-white"><CardHeader><CardTitle>Transações 30 dias</CardTitle></CardHeader><CardContent className="text-2xl font-bold">{balance?.stats_30d?.transaction_count ?? "—"}</CardContent></Card></section></div></main>;
}
