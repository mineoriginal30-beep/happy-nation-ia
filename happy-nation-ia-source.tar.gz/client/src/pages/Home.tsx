import { AIChatBox, type Message } from "@/components/AIChatBox";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowUpRight, Download, History, LogIn, Menu, Orbit, Plus, ShieldCheck, Sparkles, Trash2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const starterPrompts = [
  "Crie um plano criativo para meu próximo projeto.",
  "Explique um conceito difícil de forma simples.",
  "Ajude-me a revisar este código com boas práticas.",
];

export default function Home() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const activeRequest = useRef(0);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const chatMutation = trpc.ai.chat.useMutation();
  const historyQuery = trpc.history.list.useQuery(undefined, { enabled: Boolean(user) });
  const historyGet = trpc.history.get.useQuery({ conversationId: conversationId || 0 }, { enabled: Boolean(user && conversationId) });
  const createConversation = trpc.history.create.useMutation();
  const addHistoryMessage = trpc.history.addMessage.useMutation();
  const deleteHistoryConversation = trpc.history.delete.useMutation();

  useEffect(() => {
    const saved = localStorage.getItem("happy-nation-chat");
    if (saved) {
      try {
        setMessages(JSON.parse(saved));
      } catch {
        localStorage.removeItem("happy-nation-chat");
      }
    }

    const handler = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  useEffect(() => {
    if (messages.length && !user) localStorage.setItem("happy-nation-chat", JSON.stringify(messages));
  }, [messages, user]);

  useEffect(() => {
    if (historyGet.data) {
      setMessages(historyGet.data.messages.map(message => ({ role: message.role, content: message.content })));
    }
  }, [historyGet.data]);

  const sendMessage = async (content: string) => {
    const requestId = ++activeRequest.current;
    let activeId = conversationId;
    if (user) {
      try {
        if (!activeId) {
          activeId = await createConversation.mutateAsync({ title: content.slice(0, 54), message: { role: "user", content } });
          setConversationId(activeId);
          await historyQuery.refetch();
        } else {
          await addHistoryMessage.mutateAsync({ conversationId: activeId, message: { role: "user", content } });
        }
      } catch {
        activeId = conversationId;
      }
    }
    const nextMessages: Message[] = [...messages, { role: "user", content }];
    setMessages(nextMessages);
    chatMutation.mutate(
      { conversationId: activeId || undefined, messages: nextMessages.filter((message): message is { role: "user" | "assistant"; content: string } => message.role !== "system") },
      {
        onSuccess: response => {
          if (requestId !== activeRequest.current) return;
          let cursor = 0;
          const reveal = () => {
            if (requestId !== activeRequest.current) return;
            cursor = Math.min(response.length, cursor + 18);
            setMessages(current => [...current.filter(message => message.role !== "assistant" || current.indexOf(message) !== current.length - 1), { role: "assistant", content: response.slice(0, cursor) }]);
            if (cursor < response.length) window.setTimeout(reveal, 22);
          };
          reveal();
        },
        onError: error => {
          if (requestId !== activeRequest.current) return;
          setMessages(current => [...current, { role: "assistant", content: `Não consegui responder agora. ${error.message || "Tente novamente em instantes."}` }]);
        },
      },
    );
  };

  const cancelResponse = () => {
    activeRequest.current += 1;
    chatMutation.reset();
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    setInstallPrompt(null);
  };

  return (
    <main className="hn-shell">
      <div className="hn-noise" aria-hidden="true" />
      <header className="hn-header">
        <a className="hn-brand" href="#chat" aria-label="Happy Nation IA — início">
          <span className="hn-brand-mark"><Orbit size={20} /></span>
          <span><strong>HAPPY NATION</strong><small>IA / CONVERSATION SYSTEM</small></span>
        </a>
        <button className="hn-menu-toggle" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Abrir menu">
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        <nav className={mobileOpen ? "hn-nav is-open" : "hn-nav"}>
          <a href="#chat" onClick={() => setMobileOpen(false)}>Conversar</a>
          <a href="#principios" onClick={() => setMobileOpen(false)}>Princípios</a>
          {installPrompt && <Button variant="outline" className="hn-install" onClick={installApp}><Download size={15} /> Instalar app</Button>}
          {user ? <span className="hn-user-pill"><span className="hn-online-dot" />{user.name || "Conectado"}</span> : <Button className="hn-login" onClick={() => startLogin()}><LogIn size={15} /> Entrar</Button>}
        </nav>
      </header>

      <section className="hn-hero" id="chat">
        <div className="hn-hero-copy">
          <div className="hn-eyebrow"><span /> SISTEMA ONLINE <span className="hn-eyebrow-line" /></div>
          <h1>Converse com ideias<br /><em>sem fronteiras.</em></h1>
          <p>Um espaço inteligente para explorar, criar e construir o próximo passo. A Happy Nation IA acompanha seu raciocínio sem perder clareza, responsabilidade e propósito.</p>
          <div className="hn-trust-row"><span><ShieldCheck size={15} /> Uso responsável</span><span><Sparkles size={15} /> Respostas reais</span><span><span className="hn-pulse" /> Sempre evoluindo</span></div>
        </div>
        <div className="hn-hero-orb" aria-hidden="true"><div className="hn-orb-core"><Orbit size={70} strokeWidth={1} /></div><div className="hn-ring ring-one" /><div className="hn-ring ring-two" /><div className="hn-orb-label">H N / 01</div></div>
      </section>

      <section className="hn-chat-wrap" aria-label="Conversa com a Happy Nation IA">
        {user && <div className="hn-history-bar"><div className="hn-history-title"><History size={15} /> <span>SEU HISTÓRICO</span></div><button aria-label="Nova conversa" onClick={() => { activeRequest.current += 1; setConversationId(null); setMessages([]); }}><Plus size={14} /> nova</button>{historyQuery.data?.slice(0, 6).map(item => <button key={item.id} className={conversationId === item.id ? "is-active" : ""} onClick={() => setConversationId(item.id)} title={item.title}><span>{item.title}</span><Trash2 size={13} onClick={event => { event.stopPropagation(); deleteHistoryConversation.mutate({ conversationId: item.id }, { onSuccess: () => historyQuery.refetch() }); }} /></button>)}</div>}
        {!user && <div className="hn-history-note"><History size={14} /> Entre para salvar e continuar suas conversas em qualquer dispositivo.</div>}
        <div className="hn-chat-topline"><span>LIVE INTERFACE</span><span className="hn-chat-status"><span className="hn-pulse" /> conexão protegida</span></div>
        <AIChatBox
          messages={messages}
          onSendMessage={sendMessage}
          onCancel={cancelResponse}
          isLoading={chatMutation.isPending}
          height="min(600px, 67vh)"
          placeholder="Escreva sua próxima ideia..."
          emptyStateMessage="Por onde começamos?"
          suggestedPrompts={starterPrompts}
          className="hn-chat-box"
        />
        <div className="hn-chat-foot"><span>SHIFT + ENTER para uma nova linha</span><button aria-label="Limpar conversa" onClick={() => { setMessages([]); localStorage.removeItem("happy-nation-chat"); }}>limpar conversa <ArrowUpRight size={13} /></button></div>
      </section>

      <section className="hn-principles" id="principios">
        <div><span className="hn-section-index">01 / PRINCÍPIO</span><h2>Clareza sobre ruído.</h2></div>
        <p>A Happy Nation IA foi desenhada para ser útil, honesta e consciente. Ela ajuda a pensar melhor, sinaliza limites quando necessário e mantém suas chaves protegidas no servidor.</p>
        <div className="hn-principle-grid"><article><strong>01</strong><h3>Contexto</h3><p>Respostas que acompanham sua intenção.</p></article><article><strong>02</strong><h3>Respeito</h3><p>Tecnologia com responsabilidade humana.</p></article><article><strong>03</strong><h3>Criação</h3><p>Da primeira pergunta ao próximo movimento.</p></article></div>
      </section>

      <footer className="hn-footer"><span>HAPPY NATION IA</span><span>Base desenvolvida por <strong>Brian Lewis</strong></span><span>© {new Date().getFullYear()} / feito para criar</span></footer>
    </main>
  );
}

declare global {
  interface BeforeInstallPromptEvent extends Event {
    prompt: () => Promise<void>;
    userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
  }
}
