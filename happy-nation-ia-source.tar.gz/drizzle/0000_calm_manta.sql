CREATE TYPE "user_role" AS ENUM ('user', 'admin');
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" serial PRIMARY KEY NOT NULL,
	"userId" integer NOT NULL,
	"externalId" varchar(128) NOT NULL,
	"cashinId" varchar(128),
	"amount" numeric(12, 2) NOT NULL,
	"status" varchar(32) DEFAULT 'pending' NOT NULL,
	"qrCode" text,
	"copyPaste" text,
	"description" text,
	"createdAt" timestamp with time zone DEFAULT now() NOT NULL,
	"updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payments_externalId_unique" UNIQUE("externalId")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"openId" varchar(64) NOT NULL,
	"name" text,
	"email" varchar(320),
	"passwordHash" text,
	"cpf" varchar(11),
	"birthDate" varchar(10),
	"phone" varchar(20),
	"loginMethod" varchar(64) DEFAULT 'local',
	"role" "user_role" DEFAULT 'user' NOT NULL,
	"createdAt" timestamp with time zone DEFAULT now() NOT NULL,
	"updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
	"lastSignedIn" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_openId_unique" UNIQUE("openId"),
	CONSTRAINT "users_email_unique" UNIQUE("email"),
	CONSTRAINT "users_cpf_unique" UNIQUE("cpf")
);
--> statement-breakpoint
CREATE TABLE "withdrawals" (
	"id" serial PRIMARY KEY NOT NULL,
	"userId" integer NOT NULL,
	"cashinId" varchar(128),
	"amount" numeric(12, 2) NOT NULL,
	"pixKey" varchar(320) NOT NULL,
	"pixKeyType" varchar(16) NOT NULL,
	"status" varchar(32) DEFAULT 'processing' NOT NULL,
	"createdAt" timestamp with time zone DEFAULT now() NOT NULL,
	"updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);
