import { beforeEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { invokeLLM } from "./_core/llm";
import { extractCodeBlocks } from "../client/src/lib/codeBlocks";

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

const mockedInvokeLLM = vi.mocked(invokeLLM);

function createContext(user: TrpcContext["user"] = null): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("ai.chat", () => {
  beforeEach(() => vi.clearAllMocks());

  it("encaminha a conversa para o modelo e retorna texto", async () => {
    mockedInvokeLLM.mockResolvedValue({ choices: [{ message: { role: "assistant", content: "Olá, mundo." } }] } as never);
    const result = await appRouter.createCaller(createContext()).ai.chat({ messages: [{ role: "user", content: "Oi" }] });
    expect(result).toBe("Olá, mundo.");
    expect(mockedInvokeLLM).toHaveBeenCalledOnce();
  });

  it("rejeita mensagens vazias", async () => {
    await expect(appRouter.createCaller(createContext()).ai.chat({ messages: [{ role: "user", content: "" }] })).rejects.toThrow();
  });
});

describe("code block copy preparation", () => {
  it("extrai apenas o conteúdo do fenced code block", () => {
    expect(extractCodeBlocks("Veja:\n```ts\nconst answer = 42;\n```\nFim.")).toEqual([{ language: "ts", code: "const answer = 42;" }]);
  });
});

describe("admin.status", () => {
  it("bloqueia usuário não autenticado", async () => {
    await expect(appRouter.createCaller(createContext()).admin.status()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("permite acesso autorizado à função admin", async () => {
    const result = await appRouter.createCaller(createContext({
      id: 1,
      openId: "admin-user",
      name: "Admin",
      email: "admin@example.com",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    })).admin.status();
    expect(result).toMatchObject({ authenticated: true, role: "admin" });
  });
});
