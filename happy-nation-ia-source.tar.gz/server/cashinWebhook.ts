import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import { markPaymentStatus } from "./db";

export function registerCashinWebhook(app: Express) {
  app.post("/api/webhooks/cashinpay", async (req: Request, res: Response) => {
    const secret = process.env.CASHINPAY_WEBHOOK_SECRET;
    if (!secret) return res.status(503).json({ received: false, error: "Webhook secret not configured" });
    const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.from(JSON.stringify(req.body));
    const signature = String(req.header("X-CashinPay-Signature") || "");
    const expected = crypto.createHmac("sha256", secret).update(raw).digest("hex");
    if (!signature || signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return res.status(401).json({ received: false });
    try {
      const event = JSON.parse(raw.toString("utf8"));
      const id = event?.data?.id;
      if (event?.event?.startsWith("transaction.") && id) await markPaymentStatus(String(id), String(event.data.status || event.event.split(".")[1]));
      return res.status(200).json({ received: true });
    } catch { return res.status(400).json({ received: false }); }
  });
}
