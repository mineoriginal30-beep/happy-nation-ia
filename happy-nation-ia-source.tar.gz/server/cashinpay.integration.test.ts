import { describe, expect, it } from "vitest";
import axios from "axios";

describe("CashinPay integration", () => {
  it("authenticates with the configured production API key", async () => {
    const key = process.env.CASHINPAY_API_KEY;
    expect(key, "CASHINPAY_API_KEY must be configured").toBeTruthy();
    const response = await axios.get("https://api.cashinpaybr.com/api/v1/balance", {
      headers: { Authorization: `Bearer ${key}` },
      timeout: 15000,
    });
    expect(response.status).toBe(200);
    expect(response.data?.success).toBe(true);
  }, 20000);
});
