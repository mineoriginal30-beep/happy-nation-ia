import { and, asc, desc, eq, max } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { conversations, conversationMessages, InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (!Object.keys(updateSet).length) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt));
}

export async function getConversation(userId: number, conversationId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const conversation = (await db.select().from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.userId, userId))).limit(1))[0];
  if (!conversation) return undefined;
  const messages = await db.select().from(conversationMessages).where(eq(conversationMessages.conversationId, conversationId)).orderBy(asc(conversationMessages.position));
  return { conversation, messages };
}

export async function createConversation(userId: number, title: string, initialMessage?: { role: "user" | "assistant"; content: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(conversations).values({ userId, title: title.slice(0, 180) || "Nova conversa" });
  const conversationId = Number(result[0].insertId);
  if (initialMessage) await db.insert(conversationMessages).values({ conversationId, position: 0, ...initialMessage });
  return conversationId;
}

export async function addMessage(userId: number, conversationId: number, message: { role: "user" | "assistant"; content: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const owned = await db.select({ id: conversations.id }).from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.userId, userId))).limit(1);
  if (!owned[0]) return false;
  const [{ highest }] = await db.select({ highest: max(conversationMessages.position) }).from(conversationMessages).where(eq(conversationMessages.conversationId, conversationId));
  await db.insert(conversationMessages).values({ conversationId, position: (highest ?? -1) + 1, ...message });
  await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conversationId));
  return true;
}

export async function deleteConversation(userId: number, conversationId: number) {
  const db = await getDb();
  if (!db) return false;
  const owned = await db.select({ id: conversations.id }).from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.userId, userId))).limit(1);
  if (!owned[0]) return false;
  await db.delete(conversationMessages).where(eq(conversationMessages.conversationId, conversationId));
  await db.delete(conversations).where(eq(conversations.id, conversationId));
  return true;
}
