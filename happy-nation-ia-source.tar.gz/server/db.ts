import { eq, desc } from "drizzle-orm";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import { InsertUser, users, payments, withdrawals } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(postgres(process.env.DATABASE_URL, { max: 5, prepare: false })); } catch (error) { console.warn("[Database] Failed to connect:", error); }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb(); if (!db) return;
  const values: InsertUser = { openId: user.openId, email: user.email ?? null, name: user.name ?? null, loginMethod: user.loginMethod ?? null, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  for (const field of ["name", "email", "loginMethod"] as const) if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = values[field]; }
  if (user.role !== undefined || user.openId === ENV.ownerOpenId) { values.role = user.role ?? "admin"; updateSet.role = values.role; }
  await db.insert(users).values(values).onConflictDoUpdate({ target: users.openId, set: updateSet });
}

export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }
export async function getUserByEmail(email: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.email, email.toLowerCase())).limit(1); return result[0]; }
export async function createLocalUser(input: { name: string; email: string; cpf: string; birthDate: string; phone?: string; passwordHash: string; openId: string }) { const db = await getDb(); if (!db) throw new Error("Database unavailable"); await db.insert(users).values({ ...input, email: input.email.toLowerCase(), loginMethod: "local", role: "user" }); const rows = await db.select().from(users).where(eq(users.openId, input.openId)).limit(1); return rows[0]; }
export async function getPaymentsByUser(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(payments).where(eq(payments.userId, userId)).orderBy(desc(payments.createdAt)); }
export async function getWithdrawalsByUser(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(withdrawals).where(eq(withdrawals.userId, userId)).orderBy(desc(withdrawals.createdAt)); }
export async function insertPayment(data: typeof payments.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database unavailable"); await db.insert(payments).values(data); }
export async function insertWithdrawal(data: typeof withdrawals.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database unavailable"); await db.insert(withdrawals).values(data); }
export async function markPaymentStatus(externalId: string, status: string, cashinId?: string) { const db = await getDb(); if (!db) return; await db.update(payments).set({ status, cashinId }).where(eq(payments.externalId, externalId)); }
