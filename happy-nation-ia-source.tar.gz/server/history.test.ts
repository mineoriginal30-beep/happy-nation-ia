import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { addMessage, createConversation, deleteConversation, getConversation, listConversations } from "./db";

vi.mock("./db", () => ({
  addMessage: vi.fn(),
  createConversation: vi.fn(async () => 9),
  deleteConversation: vi.fn(),
  getConversation: vi.fn(async (userId: number, conversationId: number) => ({ conversation: { id: conversationId, userId, title: "Meu chat" }, messages: [] })),
  listConversations: vi.fn(async (userId: number) => [{ id: 1, userId, title: "Meu chat" }]),
}));

function contextFor(userId: number | null): TrpcContext {
  return {
    user: userId === null ? null : { id: userId, openId: `user-${userId}`, name: "User", email: null, loginMethod: "manus", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("history", () => {
  it("exige login para acessar conversas persistentes", async () => {
    await expect(appRouter.createCaller(contextFor(null)).history.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("lista somente o histórico associado ao usuário autenticado", async () => {
    const result = await appRouter.createCaller(contextFor(42)).history.list();
    expect(result[0]).toMatchObject({ userId: 42 });
    expect(listConversations).toHaveBeenCalledWith(42);
  });

  it("retoma uma conversa usando o usuário da sessão", async () => {
    const result = await appRouter.createCaller(contextFor(42)).history.get({ conversationId: 9 });
    expect(result?.conversation).toMatchObject({ id: 9, userId: 42 });
    expect(getConversation).toHaveBeenCalledWith(42, 9);
  });

  it("cria e sincroniza mensagens na conversa do usuário", async () => {
    const caller = appRouter.createCaller(contextFor(42));
    await caller.history.create({ title: "Ideias", message: { role: "user", content: "Primeira pergunta" } });
    await caller.history.addMessage({ conversationId: 9, message: { role: "assistant", content: "Resposta" } });
    expect(createConversation).toHaveBeenCalledWith(42, "Ideias", { role: "user", content: "Primeira pergunta" });
    expect(addMessage).toHaveBeenCalledWith(42, 9, { role: "assistant", content: "Resposta" });
  });

  it("permite excluir uma conversa pelo usuário autenticado", async () => {
    const caller = appRouter.createCaller(contextFor(42));
    await caller.history.delete({ conversationId: 9 });
    expect(deleteConversation).toHaveBeenCalledWith(42, 9);
  });
});
