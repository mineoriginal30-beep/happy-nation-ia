import { afterEach, describe, expect, it, vi } from "vitest";

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.resetModules();
});

describe("Gemini LLM adapter", () => {
  it("retorna texto Gemini no formato compatível com o chat", async () => {
    vi.stubEnv("GEMINI_API_KEY", "test-gemini-key");
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          responseId: "response-1",
          candidates: [{ content: { parts: [{ text: "Resposta Gemini." }] } }],
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      )
    );
    vi.stubGlobal("fetch", fetchMock);

    const { invokeLLM } = await import("./_core/llm");
    const result = await invokeLLM({
      messages: [
        { role: "system", content: "Seja claro." },
        { role: "user", content: "Olá" },
      ],
    });

    expect(result.choices[0]?.message.content).toBe("Resposta Gemini.");
    expect(fetchMock).toHaveBeenCalledOnce();
    expect(String(fetchMock.mock.calls[0]?.[0])).toContain("generativelanguage.googleapis.com");
    expect(String(fetchMock.mock.calls[0]?.[0])).toContain("test-gemini-key");
  });

  it("informa configuração ausente sem expor credenciais", async () => {
    vi.stubEnv("GEMINI_API_KEY", "");
    vi.stubEnv("BUILT_IN_FORGE_API_KEY", "");

    const { invokeLLM } = await import("./_core/llm");
    await expect(invokeLLM({ messages: [{ role: "user", content: "Oi" }] })).rejects.toThrow(
      "GEMINI_API_KEY is not configured"
    );
  });
});
