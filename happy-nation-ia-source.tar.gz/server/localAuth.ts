import crypto from "node:crypto";
import { promisify } from "node:util";
import { nanoid } from "nanoid";
import { SignJWT, jwtVerify } from "jose";
import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { users, type User } from "../drizzle/schema";
import { ENV } from "./_core/env";

export const LOCAL_SESSION_COOKIE = "gateway_session";
const scryptAsync = promisify(crypto.scrypt);
const secret = new TextEncoder().encode(ENV.cookieSecret || "development-only-change-me");

export async function hashPassword(password: string) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return crypto.timingSafeEqual(derived, Buffer.from(key, "hex"));
}

export async function createLocalSession(user: User) {
  return new SignJWT({ userId: user.id, role: user.role, type: "local" })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(user.id))
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret);
}

export async function getLocalUser(token?: string): Promise<User | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    const userId = Number(payload.userId);
    if (!Number.isInteger(userId)) return null;
    const db = await getDb();
    if (!db) return null;
    const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export function newLocalOpenId() {
  return `local_${nanoid(24)}`;
}
