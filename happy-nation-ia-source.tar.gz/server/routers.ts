import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { addMessage, createConversation, deleteConversation, getConversation, listConversations } from "./db";

const chatMessageSchema = z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(12000) });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  ai: router({
    chat: publicProcedure.input(z.object({ messages: z.array(chatMessageSchema).min(1).max(30), conversationId: z.number().int().positive().optional() })).mutation(async ({ input, ctx }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Você é a Happy Nation IA, uma assistente útil, clara e respeitosa. Responda em português brasileiro quando o usuário escrever em português. Ajude com criatividade, programação, estudos e ideias. Não forneça instruções para violência, fraude, invasão, abuso sexual, exploração de menores, autolesão ou outras atividades perigosas e ilegais. Quando um pedido for arriscado, explique brevemente o limite e ofereça uma alternativa segura e prática. Não alegue ter acesso a dados privados ou ações que não executou. Use Markdown quando melhorar a leitura." },
          ...input.messages,
        ],
      });
      let content = response.choices?.[0]?.message?.content;
      if (Array.isArray(content)) content = content.filter(part => part.type === "text").map(part => part.text).join("\n");
      const answer = typeof content === "string" && content.trim() ? content : "Não consegui gerar uma resposta agora. Tente novamente em instantes.";
      if (ctx.user && input.conversationId) await addMessage(ctx.user.id, input.conversationId, { role: "assistant", content: answer });
      return answer;
    }),
  }),

  history: router({
    list: protectedProcedure.query(({ ctx }) => listConversations(ctx.user.id)),
    get: protectedProcedure.input(z.object({ conversationId: z.number().int().positive() })).query(({ ctx, input }) => getConversation(ctx.user.id, input.conversationId)),
    create: protectedProcedure.input(z.object({ title: z.string().min(1).max(180), message: chatMessageSchema.optional() })).mutation(({ ctx, input }) => createConversation(ctx.user.id, input.title, input.message)),
    addMessage: protectedProcedure.input(z.object({ conversationId: z.number().int().positive(), message: chatMessageSchema })).mutation(({ ctx, input }) => addMessage(ctx.user.id, input.conversationId, input.message)),
    delete: protectedProcedure.input(z.object({ conversationId: z.number().int().positive() })).mutation(({ ctx, input }) => deleteConversation(ctx.user.id, input.conversationId)),
  }),

  admin: router({
    status: adminProcedure.query(({ ctx }) => ({ authenticated: true, role: ctx.user.role, name: ctx.user.name, notice: "Área administrativa protegida por função." })),
  }),
});

export type AppRouter = typeof appRouter;
