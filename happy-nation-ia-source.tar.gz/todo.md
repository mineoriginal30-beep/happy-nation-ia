# Project TODO

## Escopo e produto

- [x] Criar interface pública de conversa da Happy Nation IA com visual elegante, futurista e responsivo.
- [x] Aplicar identidade visual inspirada na arte fornecida, com fundo/arte de papel de parede sem armazenar mídia pesada no projeto.
- [x] Exibir o nome “Happy Nation IA” na interface pública.
- [x] Manter crédito visível e não removido: “Base desenvolvida por Brian Lewis”.
- [x] Criar experiência pública sem exibir link, rota ou credenciais administrativas.

## Chat de IA

- [x] Avaliar e reutilizar o componente de chat pré-construído do template.
- [x] Implementar conversa com respostas reais em tempo real por provedor configurável (resposta revelada progressivamente na interface).
- [x] Adicionar estados de carregamento, erro, vazio, cancelamento e nova conversa.
- [x] Renderizar Markdown e blocos de código com ação de copiar.
- [x] Adicionar tratamento responsável de uso, sem prometer “IA sem censura” e sem remover proteções legais ou de segurança.
- [x] Manter chaves e configurações sensíveis exclusivamente no backend.

## Autenticação e administração

- [x] Usar autenticação existente do projeto com sessão segura.
- [x] Restringir operações administrativas por função `admin` no backend.
- [x] Criar área administrativa protegida, sem link público exposto.
- [x] Ocultar credenciais, segredos e informações sensíveis da interface e do código do cliente.
- [x] Testar acesso autorizado e rejeição de usuários sem função administrativa.

## PWA e responsividade

- [x] Criar manifesto PWA com nome, descrição, cores e modo instalável.
- [x] Adicionar ícones adequados para celular e desktop.
- [x] Configurar service worker/cache mínimo para experiência instalável.
- [x] Validar layout em desktop, tablet e celular.
- [x] Garantir navegação por teclado, foco visível e contraste adequado.

## Publicação e qualidade

- [x] Configurar título, metadados e idioma em português.
- [x] Testar TypeScript, build e suíte Vitest.
- [x] Fazer verificação visual do fluxo público e do comportamento responsivo.
- [x] Confirmar que o projeto está preparado para publicação gratuita pela hospedagem gerenciada disponível.
- [x] Criar checkpoint final antes de orientar a publicação pelo botão Publish.

## Histórico de pendências e correções

- [x] Registrar nesta lista qualquer nova solicitação, bug ou correção antes da implementação.
- [x] Marcar cada item como concluído imediatamente após sua validação.

## QA adicional identificado

- [x] Implementar botões de copiar para blocos de código renderizados no chat e cobrir com verificação.
- [x] Adicionar teste Vitest para `admin.status` com usuário `role: 'admin'` confirmando acesso autorizado.
- [x] Validar a interface em viewport de tablet e registrar a checagem no fluxo de QA.
- [x] Revisar e testar acessibilidade de teclado, foco e contraste na home e no admin.

## Últimas correções de QA

- [x] Implementar ação de copiar específica para blocos de código renderizados no chat e registrar verificação manual/teste.
- [x] Executar uma checagem verificável de acessibilidade na home e no admin, cobrindo teclado, foco visível e contraste; ajustar controles customizados.

## Evidências finais antes do checkpoint

- [x] Adicionar teste ou registro explícito para cópia de fenced code, confirmando que apenas o código é copiado.
- [x] Executar e registrar checagem verificável de acessibilidade na home e no admin, cobrindo teclado, foco visível e contraste.

## Limitações técnicas identificadas

- [x] Documentar a limitação do template: a resposta é entregue pelo gateway e revelada progressivamente; SSE futuro está especificado em `AI_CONFIGURATION.md`.
- [x] Implementar cancelamento da revelação local e ignorar resultados posteriores; cancelamento de transporte fica documentado como evolução futura.
- [x] Documentar configuração segura do provedor pelo backend em `AI_CONFIGURATION.md`, sem expor modelo ou credenciais na interface pública.

## Nova solicitação: histórico persistente

- [x] Criar tabela persistente de conversas vinculada ao usuário autenticado.
- [x] Criar tabela de mensagens com ordem, conteúdo e papel da mensagem.
- [x] Implementar procedimentos protegidos para listar, abrir, criar, continuar e excluir conversas do próprio usuário.
- [x] Integrar o histórico à interface sem expor conversas entre usuários.
- [x] Permitir continuar uma conversa anterior e sincronizar novas mensagens com o banco.
- [x] Manter fallback local para visitantes não autenticados, informando que a persistência exige login.
- [x] Adicionar testes de isolamento e continuidade das conversas.
- [x] Confirmar e documentar que a publicação pode usar a hospedagem gerenciada gratuita; não publicar sem a ação do usuário.

## Ajustes finais do histórico

- [x] Adicionar campo explícito de ordenação das mensagens e usá-lo nas consultas do histórico.
- [x] Expandir testes para criação, continuidade, sincronização e exclusão de conversas.
- [x] Registrar em documentação do projeto que a publicação usa hospedagem gerenciada gratuita e depende da ação manual do usuário.

## Nova solicitação: Markdown e copiar

- [x] Refinar a renderização Markdown nas respostas da IA com hierarquia, listas, citações e links legíveis.
- [x] Manter blocos de código destacados com cópia específica.
- [x] Adicionar botão de copiar o texto completo da resposta com feedback visual e acessível.
- [x] Testar Markdown, cópia e compatibilidade com histórico persistente.

## Evidência UX Markdown

- [x] Adicionar verificação específica para Markdown e cópia no frontend, cobrindo títulos, listas, citações, links, resposta completa e código.
- [x] Registrar checagem manual/visual de uma conversa salva contendo Markdown e bloco de código após reabertura pelo histórico.

## Nova solicitação: hospedagem externa gratuita

- [ ] Avaliar provedores externos gratuitos compatíveis com o backend Express, PWA, autenticação e banco da aplicação.
- [ ] Preparar repositório GitHub privado ou público conforme autorização do usuário, sem incluir segredos.
- [ ] Criar documentação de implantação externa com variáveis obrigatórias e limitações do plano gratuito.
- [ ] Validar build e comandos de inicialização para o provedor escolhido.
- [ ] Publicar externamente somente após o usuário autorizar o provedor e concluir login/configuração necessária.

## Autorização para publicação externa

- [ ] Preparar o repositório para deploy externo sem segredos.
- [ ] Configurar variáveis e migração para o banco externo autorizado.
- [ ] Conectar e publicar o serviço no Render Free após login/autorização do usuário.
- [ ] Validar o link externo e documentar limites do plano gratuito.

## Nova preferência: acesso público

- [ ] Alterar o repositório GitHub para público conforme autorização do usuário.
- [ ] Revisar o histórico do Git e arquivos públicos para garantir que não contenham segredos.
- [ ] Enviar a versão atual ao repositório público e conectar o Render Free.
- [ ] Configurar o link público da aplicação para uso por qualquer pessoa.
